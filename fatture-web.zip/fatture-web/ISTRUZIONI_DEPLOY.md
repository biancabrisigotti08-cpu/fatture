# Estrattore Fatture Web — Istruzioni Deploy

## Come pubblicare su Railway (gratuito, 5 minuti)

### 1. Crea un account GitHub (se non ce l'hai)
Vai su https://github.com e registrati gratis.

### 2. Crea un nuovo repository
- Vai su https://github.com/new
- Nome: `estrattore-fatture`
- Clicca "Create repository"

### 3. Carica i file
Nella pagina del repository appena creato:
- Clicca "uploading an existing file"
- Trascina i tre file: `app.py`, `requirements.txt`, `Procfile`
- Clicca "Commit changes"

### 4. Deploy su Railway
- Vai su https://railway.app
- Clicca "Login with GitHub"
- Clicca "New Project" → "Deploy from GitHub repo"
- Seleziona `estrattore-fatture`
- Railway fa tutto automaticamente in 2-3 minuti

### 5. Ottieni il link
- Nel progetto Railway, vai su "Settings" → "Networking" → "Generate Domain"
- Ottieni un link tipo: `https://estrattore-fatture.up.railway.app`
- Condividi questo link con i colleghi!

---

## Come funziona l'app

1. Apri il link nel browser
2. Trascina i file XML o ZIP (anche più file insieme)
3. Clicca "Avvia Estrazione"
4. Il file `estrazione_fatture.xlsx` si scarica automaticamente

## Note
- Limite file: 200MB per caricamento
- I file vengono elaborati in memoria e non vengono salvati sul server
- Funziona con Chrome, Edge, Firefox, Safari
